create trigger BI_USERS_ACTIONS
	before insert
	on USERS_ACTIONS
	for each row
begin   
  if :NEW."ACTION_ID" is null then 
    select "USERS_ACTIONS_SEQ".nextval into :NEW."ACTION_ID" from dual; 
  end if; 
end; 
